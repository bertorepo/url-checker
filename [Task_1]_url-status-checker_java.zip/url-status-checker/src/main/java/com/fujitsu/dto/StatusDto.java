package com.fujitsu.dto;

public class StatusDto {
	private int status;
	private String link;
	
	public StatusDto(int status, String link) {
		this.status = status;
		this.link = link;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	@Override
	public String toString() {
		return "StatusDto [status=" + status + ", link=" + link + "]";
	}
	
	
	
}
