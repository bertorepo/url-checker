package com.fujitsu.service;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.fujitsu.dto.StatusDto;
import com.fujitsu.dto.UrlDto;

@Service
public class UrlService {

	// method to to get the Link URL and its status code and store it in a List
	// Object
	public List<StatusDto> getStatusCode(UrlDto urlDto) {

		StatusDto statusDto = null;

		List<StatusDto> linkArr = new ArrayList<>();

		try {

			String str = urlDto.getLink();
			String[] arrStr = str.split("\\r\\n");

			for (String link : arrStr) {
				int linkStatus = getResposeCode(link);
				statusDto = new StatusDto(linkStatus, link);
				linkArr.add(statusDto);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return linkArr;

	}

	// Method to generate the status code for a particular URL
	// OK = 200 | Permanent Move URL = 301 | Temporary Move URL = 302 | Not Found
	// URL = 0 or 400
	private static int getResposeCode(String url) {
		HttpURLConnection con;
		String finalUrl = url;

		int responseCode = 0;

		try {

			con = (HttpURLConnection) new URL(finalUrl).openConnection();
			con.setInstanceFollowRedirects(false);
			con.setRequestMethod("GET");
			con.connect();

			responseCode = con.getResponseCode();

			if (responseCode == 302 && responseCode < 400) {
				String redirectUrl = con.getHeaderField("Location");
				if (redirectUrl != finalUrl) {
					responseCode = HttpURLConnection.HTTP_MOVED_TEMP;
				}

//					System.out.println("Redirected URL: " + redirectUrl);
			} else if (responseCode == 301 && responseCode < 400) {
				responseCode = HttpURLConnection.HTTP_MOVED_PERM;
			}else if(responseCode == 404) {
				responseCode = HttpURLConnection.HTTP_NOT_FOUND;
			}else if (responseCode == 200) {
				responseCode = HttpURLConnection.HTTP_OK;
			} else {
				responseCode = 0;
			}

			con.disconnect();

		} catch (Exception e) {
			// error here
		}
		return responseCode;
	}

}
